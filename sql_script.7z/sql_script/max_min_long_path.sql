--ПРОДОЛЖИТЕЛЬНОСТЬ ПО РЕКАМ В БУРЯТИ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
    t.duration_days
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(buryatia) = count(row_number)

--ПРОДОЛЖИТЕЛЬНОСТЬ ПО РЕКАМ В ИРКУТСКОЙ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
    t.duration_days
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(irkutskay) = count(row_number)


--ПРОДОЛЖИТЕЛЬНОСТЬ ПО РЕКАМ В ДВУХ РЕГИОНАХ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
    t.duration_days
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having (sum(irkutskay)+sum(buryatia)) = count(row_number)
   and sum(irkutskay) != count(row_number)
    and sum(buryatia) != count(row_number)


--продолжительность ПО РЕКАМ В БУРЯТИ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
--     t.duration_days
    SUM(st_distance(geom,geom_next)*1.3)/1000
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(buryatia) = count(row_number)


--продолжительность ПО РЕКАМ В иркутской области
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
--     t.duration_days
    SUM(st_distance(geom,geom_next)*1.3)/1000
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(irkutskay) = count(row_number)


--продолжительность ПО РЕКАМ В двух регионах
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
--     t.duration_days
    SUM(st_distance(geom,geom_next)*1.3)/1000
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having (sum(irkutskay)+sum(buryatia)) = count(row_number)
   and sum(irkutskay) != count(row_number)
    and sum(buryatia) != count(row_number)


--максимальная и средняя протеженность маршрутов по иркутской области
with t as (select * from baikal_path_sep where river = 'all')
select
   sum(st_distance(geom, geom_next)*1.3)/1000,
   avg(st_distance(geom, geom_next)*1.3)/1000
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where irkutskay = 1

--максимальная и средняя протеженность маршрутов по Бурятии
with t as (select * from baikal_path_sep where river = 'all')
select
   sum(st_distance(geom, geom_next)*1.3)/1000,
   avg(st_distance(geom, geom_next)*1.3)/1000
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where buryatia = 1


--ПРОДОЛЖИТЕЛЬНОСТЬ ПО РЕКАМ В ИРКУТСКОЙ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
    t.duration_days
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(irkutskay) = count(row_number)


--ПРОДОЛЖИТЕЛЬНОСТЬ ПО РЕКАМ В ДВУХ РЕГИОНАХ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.number,
    t.duration_days
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having (sum(irkutskay)+sum(buryatia)) = count(row_number)
   and sum(irkutskay) != count(row_number)
    and sum(buryatia) != count(row_number)


--ПРОДОЛЖИТЕЛЬНОСТЬ ПО БАЙКАЛУ В ИРКУТСКОЙ
with t as (select * from baikal_path_sep where river = 'all')
select
    baikal_path_sep_point.*,
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
group by baikal_path_sep_point.number,t.duration_days
having sum(irkutskay) = count(row_number)
