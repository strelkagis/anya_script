select user_region, count(*) from baikal_photo
join region_russia
    on user_region LIKE '%name%';
--     on user_region in name or name in user_region
--                              group by user_region


SELECT user_region, count(*)
FROM baikal_photo
-- LEFT JOIN region_russia ON user_region
--                                like '%name%'
LEFT JOIN region_russia ON baikal_photo.user_region like CONCAT('%', region_russia.name, '%')
where name is null
GROUP BY user_region;

select name from region_russia