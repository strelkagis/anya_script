with t as (select * from baikal_path_sep where baikal = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc

with t as (select * from baikal_path_sep where river = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc

with t as (select * from baikal_path_sep where jeep = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc

with t as (select * from baikal_path_sep where car = 'all' or
                           car is null and
                           railway is null and
                           baikal_path_sep.pedestrian is null and
                           baikal_path_sep.river is null and
                           baikal_path_sep.baikal_winter is null and
                           baikal_path_sep.baikal is null and
                            baikal_path_sep.jeep is null and
                            baikal_path_sep.sky is null)
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc


with t as (select * from baikal_path_sep where sky = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc


with t as (select * from baikal_path_sep where baikal_winter = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc


with t as (select * from baikal_path_sep where pedestrian = 'all')
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc

with t as (select * from baikal_path_sep)
select
    name || ' ' || name_next as double_name, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
where name || ' ' || name_next is not null and name != name_next
group by name || ' ' || name_next
order by count(*) desc
--
--
-- with t as (select * from baikal_path_sep where railway = 'all')
-- select
--     name || ' ' || name_next as double_name, count(*)
-- from baikal_path_sep_point
-- join t on baikal_path_sep_point.number = t.number
-- where name || ' ' || name_next is not null and name != name_next
-- group by name || ' ' || name_next
-- order by count(*) desc
--
--
-- pedestrian
-- railway