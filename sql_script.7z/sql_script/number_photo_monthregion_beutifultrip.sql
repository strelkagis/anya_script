DROP TABLE IF EXISTS baikal_photo_around_road;
create table baikal_photo_around_road as (
with t as (
    select st_buffer(baikal_edges_pesh.geom, 100) as geom, baikal_edges_pesh.id from baikal_edges_pesh
)

select
    baikal_photo.geom as geom_photo,
    baikal_photo.id  as id_photo,
    t.id as id_road,
    month
from t
join baikal_photo on st_intersects(t.geom, baikal_photo.geom))

alter table baikal_photo_around_road add column region text;

CREATE INDEX "baikal_photo_around_road_geom" ON  "baikal_photo_around_road" USING GIST (geom_photo);

update baikal_photo_around_road set region = name
from baikal_area where st_intersects(baikal_photo_around_road.geom_photo, baikal_area.geom)

select * from baikal_photo_around_road

select region, month, count(*) from baikal_photo_around_road group by region, month

DROP TABLE IF EXISTS baikal_photo_around_road_summer;
create table baikal_photo_around_road_summer as (
with t as (
    select st_buffer(baikal_edges_pesh.geom, 100) as geom, baikal_edges_pesh.id from baikal_edges_pesh
)

select
    baikal_photo.geom as geom_photo,
    baikal_photo.id  as id_photo,
    t.id as id_road
from t
join baikal_photo on st_intersects(t.geom, baikal_photo.geom)
 where month between 5 and 10)

CREATE INDEX "baikal_photo_around_road_summer_geom" ON  "baikal_photo_around_road_summer" USING GIST (geom_photo);
alter table baikal_photo_around_road_summer add column region text;

update baikal_photo_around_road_summer set region = name
                                       from baikal_area where st_intersects(baikal_photo_around_road_summer.geom_photo, baikal_area.geom)


DROP TABLE IF EXISTS baikal_photo_around_road_winter;
create table baikal_photo_around_road_winter as (
with t as (
    select st_buffer(baikal_edges_pesh.geom, 100) as geom, baikal_edges_pesh.id from baikal_edges_pesh
)

select
    baikal_photo.geom as geom_photo,
    baikal_photo.id  as id_photo,
    t.id as id_road
from t
join baikal_photo on st_intersects(t.geom, baikal_photo.geom)
 where month < 5 or month > 10)

CREATE INDEX "baikal_photo_around_road_winter_geom" ON  "baikal_photo_around_road_winter" USING GIST (geom_photo);
alter table baikal_photo_around_road_winter add column region text;

update baikal_photo_around_road_winter set region = name
                                       from baikal_area where st_intersects(baikal_photo_around_road_winter.geom_photo, baikal_area.geom)

select * from baikal_edges_pesh