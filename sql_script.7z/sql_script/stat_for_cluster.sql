-- select * from baikal_only_lines_with_point
-- select * from baikal_path_unnest_main


with t as (
select
    geom,
    lead(geom, 1) over (partition by number order by row_number) as geom_next,
    number,
    row_number,
    river,
    railway,
    pedestrian,
    car,
    baikal,
    jeep,
    sky
from baikal_path_update),

line as (
select
    st_union(st_makeline(geom, geom_next)) as line_geom,
    number,
    river,
    railway,
    pedestrian,
    car,
    baikal,
    jeep,
    sky
from t
where car != 'all' or river != 'all'
    or railway != 'all'
    or pedestrian != 'all'
    or car != 'all'
    or baikal != 'all'
    or jeep != 'all'
    or sky != 'all'

group by number, river,
    railway,
    pedestrian,
    car,
    baikal,
    jeep,
    sky)

SELECT
    count(st_intersection(geom, line_geom)),
    layer
FROM line
right join baikal_cluster_new
        on st_intersects(line_geom, geom)
where
    river is not null or
    railway is not null or
    pedestrian is not null or
    car is not null or
    baikal is not null or
    jeep is not null or
    sky is not null
group by layer
order by layer
