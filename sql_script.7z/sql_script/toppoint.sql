--топовые точки Байкал
-- create table baikal_path_sep as (
with t as (select number from baikal_path_sep where baikal = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

with t as (select number from baikal_path_sep where river = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

with t as (select number from baikal_path_sep where car = 'all' or
                           car is null and
                           railway is null and
                           baikal_path_sep.pedestrian is null and
                           baikal_path_sep.river is null and
                           baikal_path_sep.baikal_winter is null and
                           baikal_path_sep.baikal is null and
                            baikal_path_sep.jeep is null and
                            baikal_path_sep.sky is null)
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

with t as (select number from baikal_path_sep where jeep = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

select * from baikal_path_sep

with t as (select number from baikal_path_sep where baikaL_winter = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

with t as (select number from baikal_path_sep where pedestrian = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10

with t as (select number from baikal_path_sep where sky = 'all')
select
    name, geom, count(*)
from baikal_path_sep_point
join t on baikal_path_sep_point.number = t.number
group by name, geom
order by count(*) desc
limit 10


