CREATE OR REPLACE FUNCTION  "public"."habitatum"()
  RETURNS int4

AS
$BODY$

DECLARE

_record record;
_owner_id int;
_count int;
_median float8;
_cluster int;
_record_cluster record;
-- _node_id_next int;
-- _node_id int;
_geom geometry;

BEGIN

    FOR _record in
        SELECT
            owner_id,
            count(distinct cast(date_time as date)) as count_data,
            count(*) AS count,
            ROW_NUMBER() OVER (ORDER BY count(*)) AS rownum
        FROM kurskiy_photos
        WHERE
            in_out = 1 AND
            owner_id != 0
        GROUP BY owner_id
        HAVING COUNT(*) < 200 and count(distinct cast(date_time as date)) > 7
        ORDER BY count(*)

		LOOP
    	--взяли название слоя
		_owner_id := _record.owner_id;
		_count := _record.count;

        RAISE NOTICE '_owner_id %', _owner_id;


        FOR _record_cluster in SELECT ST_ClusterDBSCAN(geom, eps := 1000, minpoints := 2) OVER () as cluster, geom
            FROM kurskiy_photos where owner_id = _owner_id

                LOOP

                    _cluster := _record_cluster.cluster;
                    _geom := _record_cluster.geom;

                    RAISE NOTICE '_cluster %', _cluster;

                END LOOP;

--     	SELECT
--             _owner_id,
--             PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY dist) AS median
--         from
--             --максимальное расстояние у 75 процентов всех фотографий пользователя
--             PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY dist) AS cvantil,
--             --медианное расстояние между всеми фотографиями одного ползователя
--             PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY dist) AS median,
--             --максимальное расстояние у 75 процентов всех фотографий пользователя
--             PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY dist) AS cvantil_3_4
-- --             MIN(photo_count_90) as min_90
--         FROM kurskiy_photos_main
--         CROSS JOIN LATERAL (
--             SELECT
--                 two.id,
--                 ST_Distance(two.geom, kurskiy_photos_main.geom) AS dist
--         --         count(*)
--             FROM kurskiy_photos_main AS two
--             WHERE two.id != kurskiy_photos_main.id AND two.owner_id = kurskiy_photos_main.owner_id
--             ORDER BY kurskiy_photos_main.geom <-> two.geom DESC
--         --             MIN(photo_count_90)
--             LIMIT 1
--         ) AS closest_point
--         GROUP BY owner_id)
--
-- 			with prob_table as (
-- 				SELECT * FROM pgr_Dijkstra(
-- 					'select id, source, target, cost, reverse_cost from _edges_graph_russia_spb_part',
-- 					_node_id, _node_id_next, true))
-- 			select
-- 				ST_LineMerge(st_union(geometry)) into _line_geom
-- 			from
-- 				_edges_graph_russia_spb_part
-- 			join
-- 				prob_table
-- 			on
-- 				_edges_graph_russia_spb_part.id = prob_table.edge;
--
--
--
-- 			RAISE NOTICE '__line_geom %', _line_geom;
-- 			RAISE NOTICE '__node_id_next %', _node_id_next;
-- 			RAISE NOTICE '__node_id %', _node_id;
--
--
-- 			update msk_spb_main_spb_path set line_geom = _line_geom
-- 			where node_from_id = _node_id and node_to_id = _node_id_next;
--
--
--
			END LOOP;

	RETURN 1;
END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;


select * from "public"."habitatum"()

-- select
--  ST_LINEMERGE(line_geom), count(*)
-- from
-- 	msk_spb_main_spb_path
-- group by owner_id, cluster

-- select * from msk_spb_main_spb_path_raion
--
-- select * from spb_mun_raions join msk_spb_main_spb_path on
--
-- create table msk_spb_main_spb_path_raion as (
-- SELECT a.name, id, line_geom, "Число лиц в КСР", "% в общем турпотоке", "Турпоток (поездок), 2022"
-- FROM spb_mun_raions a
-- JOIN msk_spb_main_spb_path b ON a.name LIKE concat('%', b.name, '%'));
--
-- SELECT *
--   FROM spb_mun_raions a
--   JOIN msk_spb_main_spb_path b ON b.name LIKE '%'+ a.name +'%'
--
-- select * from baikal_photo_route_auto_edge_group_tourism group by group_toursim
--
-- select distinct user_region, group_toursim from baikal_photo where group_toursim = 2