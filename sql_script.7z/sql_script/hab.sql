CREATE OR REPLACE FUNCTION  "public"."habitatum"()
  RETURNS int4

AS
$BODY$

DECLARE

_record record;
_owner_id int;
_count int;
_median float8;
_cluster int;
_record_cluster record;
-- _node_id_next int;
-- _node_id int;
_geom geometry;
_collect_geom geometry;
_id int[];

BEGIN

delete from cluster_geom_table where owner_id is not null;


    FOR _record in
        SELECT
            owner_id,
            count(distinct cast(date_time as date)) as count_data,
            count(*) AS count,
            ROW_NUMBER() OVER (ORDER BY count(*)) AS rownum
        FROM kurskiy_photos
        WHERE
            in_out = 1 AND
            owner_id != 0
        GROUP BY owner_id
        HAVING COUNT(*) < 200 and count(distinct cast(date_time as date)) > 7
        ORDER BY count(*)

		LOOP
    	--взяли название слоя
		_owner_id := _record.owner_id;
		_count := _record.count;

        RAISE NOTICE '_owner_id %', _owner_id;


        _collect_geom = st_centroid(ST_CollectionExtract(ST_DelaunayTriangles(st_collect(geom)))) from
            (SELECT ST_ClusterDBSCAN(geom, eps := 200, minpoints := 2) OVER () as cluster, id, geom FROM kurskiy_photos where owner_id = _owner_id) a
            where cluster = 0 and st_astext(geom) != 'GEOMETRYCOLLECTION EMPTY';

        _id = array_agg(id) from
            (SELECT ST_ClusterDBSCAN(geom, eps := 200, minpoints := 2) OVER () as cluster, id, geom FROM kurskiy_photos where owner_id = _owner_id) a
            where cluster = 0 and st_astext(geom) != 'GEOMETRYCOLLECTION EMPTY';

    	RAISE NOTICE '_collect_geom %', _collect_geom;

    	insert into cluster_geom_table (owner_id, geom) VALUES (_owner_id, _collect_geom);
--     	update cluster_geom set owner_id = _owner_id

		END LOOP;

--     drop table if exists cluster_geom_itog;
--     create table cluster_geom_itog as (
--     with t as (
--     select ST_ClusterDBSCAN(geom, eps := 500, minpoints := 2) OVER () as cluster_itog, owner_id from cluster_geom_table)
--     select t.owner_id, cluster_itog, kurskiy_photos.geom, id  from t join kurskiy_photos on t.owner_id = kurskiy_photos.owner_id where id in unnest(_id));



--     DROP TABLE IF EXISTS cluster_geom_itog;
--     CREATE TABLE cluster_geom_itog AS (
--       WITH t AS (
--         SELECT ST_ClusterDBSCAN(geom, eps := 500, minpoints := 2) OVER () AS cluster_itog, owner_id
--         FROM cluster_geom_table
--       )
    update cluster_geom_table set itog_cluster = cluster_itog from
    (SELECT ST_ClusterDBSCAN(geom, eps := 500, minpoints := 2) OVER () AS cluster_itog, owner_id
        FROM cluster_geom_table
      ) a where cluster_geom_table.owner_id =  a.owner_id;


	RETURN 1;
END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;


select * from "public"."habitatum"()

-- select
--  ST_LINEMERGE(line_geom), count(*)
-- from
-- 	msk_spb_main_spb_path
-- group by owner_id, cluster

-- select * from msk_spb_main_spb_path_raion
--
-- select * from spb_mun_raions join msk_spb_main_spb_path on
--
-- create table msk_spb_main_spb_path_raion as (
-- SELECT a.name, id, line_geom, "Число лиц в КСР", "% в общем турпотоке", "Турпоток (поездок), 2022"
-- FROM spb_mun_raions a
-- JOIN msk_spb_main_spb_path b ON a.name LIKE concat('%', b.name, '%'));
--
-- SELECT *
--   FROM spb_mun_raions a
--   JOIN msk_spb_main_spb_path b ON b.name LIKE '%'+ a.name +'%'
--
-- select * from baikal_photo_route_auto_edge_group_tourism group by group_toursim
--
-- select distinct user_region, group_toursim from baikal_photo where group_toursim = 2

select * from cluster_geom_itog
select * from cluster_geom_table

select distinct geom from cluster_geom_itog

ALTER TABLE cluster_geom_itog ADD COLUMN id BIGSERIAL PRIMARY KEY;

select ST_CollectionExtract(ST_DelaunayTriangles() from cluster_geom_table

select
    ST_CollectionExtract(ST_DelaunayTriangles(st_collect(geom))),
    itog_cluster
from cluster_geom_table group by itog_cluster
        where itog_cluster is not null