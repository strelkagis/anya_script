CREATE OR REPLACE FUNCTION  "public"."habitatum"(_eps int4, _minpoints int4, p_table_name varchar)
  RETURNS int4

AS
$BODY$

DECLARE

_record record;
_owner_id int;
_count int;
_geom geometry;
_geom_centroid geometry;
_id int[];
_collect_geom geometry[];

BEGIN

drop table if exists photos;
EXECUTE 'CREATE TABLE photos AS select * from '|| p_table_name || ' ';

delete from cluster_geom_table where owner_id is not null;

    FOR _record in
        SELECT
            owner_id,
            count(distinct cast(date_time as date)) as count_data,
            count(*) AS count,
            ROW_NUMBER() OVER (ORDER BY count(*)) AS rownum
        FROM photos
        WHERE
            in_out = 1 AND
            owner_id != 0
        GROUP BY owner_id
        HAVING COUNT(*) < 200 and count(distinct cast(date_time as date)) > 7
        ORDER BY count(*)

		LOOP
--         пробегаемся по каждому пользователю
		_owner_id := _record.owner_id;
		_count := _record.count;

--         RAISE NOTICE '_owner_id %', _owner_id;

--         разбиваем на кластера и агрегируем геометрию в коллекцию
        _geom_centroid = st_centroid(ST_CollectionExtract(ST_DelaunayTriangles(st_collect(geom)))) from
            (SELECT ST_ClusterDBSCAN(geom, eps := _eps, minpoints := _minpoints) OVER () as cluster, id, geom FROM photos where owner_id = _owner_id) a
            where cluster = 0 and st_astext(geom) != 'GEOMETRYCOLLECTION EMPTY';

--         разбиваем на кластера и агрегируем геометрию в коллекцию
        _collect_geom = array_agg(geom) from
            (SELECT ST_ClusterDBSCAN(geom, eps := _eps, minpoints := _minpoints) OVER () as cluster, id, geom FROM photos where owner_id = _owner_id) a
            where cluster = 0 and st_astext(geom) != 'GEOMETRYCOLLECTION EMPTY';

--         RAISE NOTICE '_collect_geom%', _collect_geom;

--         собираем все id
        _id =  array_agg(id) from
            (SELECT ST_ClusterDBSCAN(geom, eps := _eps, minpoints := _minpoints) OVER () as cluster, id, geom FROM photos where owner_id = _owner_id) a
            where cluster = 0 and st_astext(geom) != 'GEOMETRYCOLLECTION EMPTY';

    	RAISE NOTICE '_id%', _id;

    	insert into cluster_geom_table (owner_id, geom, id_array, geom_agg) VALUES (_owner_id, _geom_centroid, _id, _collect_geom);

		END LOOP;

    update cluster_geom_table set itog_cluster = cluster_itog from
    (SELECT ST_ClusterDBSCAN(geom, eps := _eps*2, minpoints := 2) OVER () AS cluster_itog, owner_id
        FROM cluster_geom_table
      ) a where cluster_geom_table.owner_id =  a.owner_id;

--     update cluster_geom_table set id_array = _id from where cluster_geom_table.owner_id =  _owner_id;
    drop table if exists habitatum;
    create table habitatum
        as (with t as (select
                owner_id,
                itog_cluster,
                unnest(id_array) as id,
                unnest(geom_agg) as point_geom
            from cluster_geom_table where itog_cluster is not null)

        select
            itog_cluster,
            ST_ChaikinSmoothing(ST_ConcaveHull(ST_Collect(point_geom), 0.5, false)) as geom
        from t
            group by itog_cluster);
	RETURN 1;
END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;


select * from "public"."habitatum"(1000, 2, 'photo_barnaul');
--
--
-- select itog_cluster, st_astext(geom) from habitatum


-- select * from cluster_geom_table
